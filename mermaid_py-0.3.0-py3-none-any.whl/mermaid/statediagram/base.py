class BaseTransition:
    pass
